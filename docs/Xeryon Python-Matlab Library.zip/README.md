# Python-Matlab-Library
Xeryon Python/Matlab Library client's can use to control our stages

How to use: https://xeryon.com/software/xeryon-python-library/

## Files:
These two are the two only required files:
* settings_default.txt: a sample file, you have to replace this one with the one provided with the Windows Interface
* Xeryon.py: this is the library. 

Example files:
* Xeryon Python: Jupyter manual.ipynb: This is an example file that can be used in Juypter (another environment to run Python), as is used in the video.
* python example.py: an example Python file
* matlabexample.m: an example Matlab file
